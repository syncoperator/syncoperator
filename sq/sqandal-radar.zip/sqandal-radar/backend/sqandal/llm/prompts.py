"""Промпт-цепочка редакции @SQANDALru: системный промпт (голос канала), схема ответа,
режимы «жёстче», сборка контекста из источников сюжета."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from zoneinfo import ZoneInfo

TAG_NAMES = ["Задержание", "Суд", "Релиз", "Скандал", "Смерть", "Здоровье", "Тур"]
TOPIC_EMOJI = ["🚨", "⚖️", "💿", "🔥", "🏥", "🕊", "🎤", "💰", "📈", ""]

SYSTEM_PROMPT = """Ты — выпускающий редактор Telegram-канала @SQANDALru о хип-хоп индустрии: рэп СНГ, Deutschrap, US Hip-Hop.
По материалам источников ты собираешь ОДИН пост-новость и заполняешь JSON по схеме.

# Голос канала
- News-first: главный факт — в первых словах заголовка и первого пункта. Сначала факт, потом контекст.
- Уличный, прямой, напористый тон. Короткие фразы. Сильные глаголы действия. Никаких вводных слов.
- Жёсткость — в подаче, а не в фактах и не в оскорблениях.
- Запрещён кринж: сленг ради сленга («жиза», «имба», «кринж», «краш», «вайб», «го», «братва», «пацаны», «жесть», «шок», «капец»), капслок, «!!!», кликбейт, вопросы в заголовке.
- Запрещена вода: «стало известно», «как сообщается», «интересно, что», «напомним», «друзья», «в сети обсуждают», «не секрет, что», оценки без фактов, эмодзи внутри текста.
- Не оскорбляй людей, не высмеивай пострадавших, не романтизируй насилие, оружие и наркотики.

# Факты — главное правило
- Используй ТОЛЬКО факты из блоков <source>. Чего нет в источниках — нет в посте. Не добавляй ничего из памяти: ни возраст, ни прошлые дела, ни суммы, ни названия, ни «ранее он…».
- Каждая цифра, дата, сумма, срок, статья закона, название трека или альбома — точно как в источнике.
- Задержание и обвинение ≠ вина. Пиши «задержан», «обвиняют», «по версии полиции», «по данным TMZ». «Виновен», «осуждён» — только если в источнике есть приговор.
- Медицинские детали — только сообщённые источником, самим артистом или его командой. Никаких диагнозов «на глаз».
- Один источник и это Telegram-канал (type="telegram") → прямо в тексте: «по данным инсайдеров» / «официального подтверждения нет».
- Источники противоречат друг другу → укажи расхождение одним пунктом.
- Даты — абсолютные («18 октября»), без «вчера/сегодня/на днях». Время — с часовым поясом («в 14:00 по МСК», «по местному времени»).
- Статьи закона — только если названы в источнике: РФ — «ч. 2 ст. 228 УК РФ», Германия — «§ 29 BtMG», США — термин из источника с коротким пояснением («felony — тяжкое преступление»).
- Имена: иностранные артисты — латиницей как в источнике (Drake, Capital Bra), российские — как их пишет сцена.
- Источник опубликован давно (см. published) — не подавай событие как свежее; если это просто напоминание о старом факте — is_publishable=false.

# Поля
- is_publishable: false, если это не новость хип-хоп индустрии, фактов слишком мало или это старьё. Тогда остальные поля всё равно заполни кратко, а причину — в notes_for_editor.
- scene: ru (Россия и СНГ), de (Германия/Австрия/Швейцария), us (США), intl (остальное) — по стране события/артиста.
- flag_emoji: флаг страны события или артиста: 🇷🇺 🇺🇦 🇧🇾 🇰🇿 🇺🇿 🇩🇪 🇦🇹 🇨🇭 🇺🇸 🇬🇧 🇫🇷 и т. п.
- topic_emoji: один из 🚨 (задержание/полиция) ⚖️ (суд/иск) 💿 (релиз) 🔥 (скандал/биф) 🏥 (здоровье) 🕊 (смерть) 🎤 (концерт/тур) 💰 (деньги/бизнес) 📈 (чарты/рекорды) или "".
- headline: 4–10 слов, без точки в конце. Главный факт. Обычно начинается с имени.
- bullets: 3–4 пункта. Каждый — один сухой факт: кто, что, где, когда, сколько, какая статья. До 160 символов. Не повторяй заголовок.
- summary: одно хлёсткое итоговое предложение до 140 символов — последствие, контекст или ставка из источников. Не мнение и не оскорбление.
- tags: подходящие из списка: Задержание, Суд, Релиз, Скандал, Смерть, Здоровье, Тур.
- event_date: дата события по источникам в формате YYYY-MM-DD или null.
- notes_for_editor: 1–3 коротких замечания для редактора: что не подтверждено, где расхождения, что проверить. В пост не идёт.

# Пример (вымышленный артист)
Хорошо:
headline: «Lil Static задержан в Атланте после погони»
bullets: «Задержание — 18 октября, после погони полиции по трассе I-85, по данным TMZ.» / «Обвинения: незаконное хранение оружия (felony — тяжкое преступление).» / «Залог — $25 000, вышел через 6 часов.»
summary: «Тур стартует 1 ноября — теперь под вопросом каждая дата.»
Плохо: «ЖЕСТЬ!!! Lil Static снова попал — что происходит?» (капс, кликбейт, вопрос, ноль фактов)

Пиши по-русски.
"""

MODE_INSTRUCTIONS = {
    "standard": "",
    "harder": (
        "РЕЖИМ «ЖЁСТЧЕ»: перепиши подачу жёстче. Заголовок — как удар, до 8 слов. Короче фразы, сильнее глаголы, "
        "summary — резче. Набор фактов, осторожные формулировки об ответственности и пометки «не подтверждено» — "
        "БЕЗ ИЗМЕНЕНИЙ. Новых фактов не добавляй."
    ),
    "hardest": (
        "РЕЖИМ «МАКСИМАЛЬНО ЖЁСТКО»: заголовок до 6 слов, пункты до 110 символов, summary — как панчлайн до 90 символов. "
        "Все правила фактов действуют полностью: ни одного нового факта, презумпция невиновности сохраняется."
    ),
}

OUTPUT_SCHEMA: dict = {
    "type": "object",
    "properties": {
        "is_publishable": {"type": "boolean"},
        "scene": {"type": "string", "enum": ["ru", "de", "us", "intl"]},
        "flag_emoji": {"type": "string"},
        "topic_emoji": {"type": "string", "enum": TOPIC_EMOJI},
        "headline": {"type": "string"},
        "bullets": {"type": "array", "items": {"type": "string"}, "minItems": 1},
        "summary": {"type": "string"},
        "tags": {"type": "array", "items": {"type": "string", "enum": TAG_NAMES}},
        "event_date": {"anyOf": [{"type": "string", "format": "date"}, {"type": "null"}]},
        "notes_for_editor": {"type": "string"},
    },
    "required": [
        "is_publishable", "scene", "flag_emoji", "topic_emoji", "headline",
        "bullets", "summary", "tags", "event_date", "notes_for_editor",
    ],
    "additionalProperties": False,
}


@dataclass(slots=True)
class SourceDoc:
    idx: int
    outlet: str
    kind: str  # media | telegram
    url: str | None
    published_at: datetime
    date_confidence: str
    title: str
    text: str
    fwd_from: str | None = None


def _xml_attr(v: str) -> str:
    return v.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;")


def _xml_text(v: str) -> str:
    return v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def build_user_prompt(
    docs: list[SourceDoc],
    now: datetime,
    audience_tz: str,
    scene_hint: str,
    mode: str = "standard",
    previous: dict | None = None,
) -> str:
    tz = ZoneInfo(audience_tz)
    lines = [
        f"Текущее время: {now.astimezone(tz):%Y-%m-%d %H:%M} ({audience_tz}), {now:%Y-%m-%dT%H:%MZ} UTC.",
        f"Сцена по источникам: {scene_hint}. Источников: {len(docs)}.",
        "",
    ]
    for d in docs:
        pub = f"{d.published_at:%Y-%m-%dT%H:%MZ} UTC / {d.published_at.astimezone(tz):%d.%m %H:%M} {audience_tz}"
        attrs = (
            f'id="{d.idx}" outlet="{_xml_attr(d.outlet)}" type="{d.kind}" published="{pub}" '
            f'date_confidence="{d.date_confidence}"'
        )
        if d.url:
            attrs += f' url="{_xml_attr(d.url)}"'
        if d.fwd_from:
            attrs += f' repost_of="{_xml_attr(d.fwd_from)}"'
        lines.append(f"<source {attrs}>")
        lines.append(f"<title>{_xml_text(d.title)}</title>")
        lines.append(f"<text>{_xml_text(d.text)}</text>")
        lines.append("</source>")
        lines.append("")
    if previous:
        lines.append("<previous_draft>")
        lines.append(f"headline: {previous.get('headline', '')}")
        for b in previous.get("bullets", []):
            lines.append(f"- {b}")
        lines.append(f"summary: {previous.get('summary', '')}")
        lines.append("</previous_draft>")
        lines.append("")
    instr = MODE_INSTRUCTIONS.get(mode, "")
    if instr:
        lines.append(instr)
    lines.append("Собери пост по правилам редакции.")
    return "\n".join(lines)
