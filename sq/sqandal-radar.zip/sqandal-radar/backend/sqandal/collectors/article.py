"""Извлечение статьи из HTML: заголовок, ДАТА ПЕРВОИСТОЧНИКА, текст, картинка.

Порядок доверия к дате (от высокого к низкому):
  JSON-LD datePublished → meta article:published_time и аналоги → <time datetime>
  → дата в URL (/2026/10/16/) → нет даты (время обнаружения).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Any
from urllib.parse import urljoin

from bs4 import BeautifulSoup, Tag

from ..models import DateSource
from ..textutil import collapse_ws, detect_lang
from ..timeutil import date_from_url, parse_datetime

ARTICLE_TYPES = {
    "newsarticle", "article", "blogposting", "reportagenewsarticle",
    "analysisnewsarticle", "backgroundnewsarticle", "socialmediaposting", "webpage",
}

META_DATE_KEYS = [
    ("property", "article:published_time"),
    ("property", "og:article:published_time"),
    ("name", "article:published_time"),
    ("itemprop", "datePublished"),
    ("name", "pubdate"),
    ("name", "publishdate"),
    ("name", "publish-date"),
    ("name", "parsely-pub-date"),
    ("name", "sailthru.date"),
    ("name", "dc.date.issued"),
    ("name", "DC.date.issued"),
    ("name", "date"),
    ("property", "og:updated_time"),  # последний шанс — это дата обновления
]

_BLOCK_JUNK = ["script", "style", "noscript", "iframe", "form", "nav", "aside", "footer", "header", "figure", "button"]
_BODY_SELECTORS = [
    "[itemprop=articleBody]",
    "article",
    ".article-body", ".article__body", ".article-content", ".entry-content", ".post-content",
    ".post__text", ".news-text", ".content-body", ".story-body", "main",
]


@dataclass(slots=True)
class ArticleData:
    title: str | None = None
    description: str | None = None
    text: str | None = None
    published_at: datetime | None = None
    date_source: DateSource = DateSource.fetched
    date_has_tz: bool = False
    modified_at: datetime | None = None
    author: str | None = None
    image_url: str | None = None
    lang: str | None = None
    canonical: str | None = None


def _iter_jsonld(obj: Any):
    if isinstance(obj, list):
        for x in obj:
            yield from _iter_jsonld(x)
    elif isinstance(obj, dict):
        if "@graph" in obj:
            yield from _iter_jsonld(obj["@graph"])
        yield obj


def _types(obj: dict) -> set[str]:
    t = obj.get("@type", [])
    if isinstance(t, str):
        t = [t]
    return {str(x).lower() for x in t}


def _first_str(v: Any) -> str | None:
    if v is None:
        return None
    if isinstance(v, str):
        return v
    if isinstance(v, list) and v:
        return _first_str(v[0])
    if isinstance(v, dict):
        return _first_str(v.get("name") or v.get("url") or v.get("@id"))
    return str(v)


def _parse_jsonld(soup: BeautifulSoup) -> dict | None:
    best = None
    for script in soup.find_all("script", attrs={"type": re.compile(r"ld\+json", re.I)}):
        raw = script.string or script.get_text() or ""
        raw = raw.strip()
        if not raw:
            continue
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            try:  # частая поломка: управляющие символы внутри строк
                data = json.loads(re.sub(r"[\x00-\x1f]", " ", raw))
            except json.JSONDecodeError:
                continue
        for obj in _iter_jsonld(data):
            types = _types(obj)
            if types & ARTICLE_TYPES and ("datePublished" in obj or "headline" in obj):
                # статья важнее WebPage
                if best is None or ("webpage" in _types(best) and "webpage" not in types):
                    best = obj
    return best


def _meta(soup: BeautifulSoup, attr: str, key: str) -> str | None:
    tag = soup.find("meta", attrs={attr: key})
    if tag and tag.get("content"):
        return str(tag["content"]).strip()
    return None


def _main_text(soup: BeautifulSoup) -> str | None:
    for junk in soup(_BLOCK_JUNK):
        junk.decompose()
    best_text, best_len = None, 0
    candidates: list[Tag] = []
    for sel in _BODY_SELECTORS:
        candidates.extend(soup.select(sel))
    if not candidates and soup.body:
        candidates = [soup.body]
    for c in candidates:
        paras = [collapse_ws(p.get_text(" ", strip=True)) for p in c.find_all(["p", "li", "h2", "blockquote"])]
        paras = [p for p in paras if len(p) >= 30]
        text = "\n".join(paras)
        if len(text) > best_len:
            best_text, best_len = text, len(text)
    return best_text or None


def extract_article(html: str, url: str, assume_tz: str | None = None) -> ArticleData:
    soup = BeautifulSoup(html, "lxml")
    out = ArticleData()

    html_tag = soup.find("html")
    if html_tag and html_tag.get("lang"):
        out.lang = str(html_tag["lang"]).split("-")[0].lower()[:8]

    canon = soup.find("link", rel=lambda v: v and "canonical" in v)
    if canon and canon.get("href"):
        out.canonical = urljoin(url, str(canon["href"]))

    ld = _parse_jsonld(soup)
    if ld:
        out.title = collapse_ws(_first_str(ld.get("headline")) or "") or None
        out.description = _first_str(ld.get("description"))
        body = ld.get("articleBody")
        if isinstance(body, str) and len(body) > 80:
            out.text = collapse_ws(body)
        out.author = _first_str(ld.get("author"))
        img = ld.get("image")
        out.image_url = _first_str(img.get("url") if isinstance(img, dict) else img)
        dt, has_tz = parse_datetime(_first_str(ld.get("datePublished")), assume_tz)
        if dt:
            out.published_at, out.date_source, out.date_has_tz = dt, DateSource.jsonld, has_tz
        out.modified_at, _ = parse_datetime(_first_str(ld.get("dateModified")), assume_tz)

    if out.published_at is None:
        for attr, key in META_DATE_KEYS:
            dt, has_tz = parse_datetime(_meta(soup, attr, key), assume_tz)
            if dt:
                out.published_at, out.date_source, out.date_has_tz = dt, DateSource.meta, has_tz
                break

    if out.published_at is None:
        scope = soup.find("article") or soup
        t = scope.find("time", attrs={"datetime": True})
        if t:
            dt, has_tz = parse_datetime(str(t["datetime"]), assume_tz)
            if dt:
                out.published_at, out.date_source, out.date_has_tz = dt, DateSource.time_tag, has_tz

    if out.published_at is None:
        dt = date_from_url(url)
        if dt:
            out.published_at, out.date_source, out.date_has_tz = dt, DateSource.url, False

    if not out.title:
        out.title = (
            _meta(soup, "property", "og:title")
            or _meta(soup, "name", "twitter:title")
            or (collapse_ws(soup.h1.get_text(" ", strip=True)) if soup.h1 else None)
            or (collapse_ws(soup.title.get_text()) if soup.title else None)
        )
    out.description = out.description or _meta(soup, "property", "og:description") or _meta(soup, "name", "description")
    if not out.image_url:
        out.image_url = _meta(soup, "property", "og:image")
    if out.image_url:
        out.image_url = urljoin(url, out.image_url)

    if not out.text:
        out.text = _main_text(soup)
    if not out.lang:
        out.lang = detect_lang(" ".join(x for x in (out.title, out.text) if x))
    return out
