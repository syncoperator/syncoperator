import { useEffect, useState } from "react";
import { ago, clock, SCENES } from "../lib/format.js";
import { IconAntenna, IconRefresh, IconX } from "./Icons.jsx";
import { Wordmark } from "./Login.jsx";

export function Header({ stats, connected, onCollect, collecting, onSources, onLogout, demo }) {
  const crit = stats?.by_priority?.CRITICAL ?? 0;
  const high = stats?.by_priority?.HIGH ?? 0;
  return (
    <header className="top">
      <Wordmark />
      <span className={`live ${connected ? "on" : ""}`} title={connected ? "Лента обновляется в реальном времени" : "Переподключение…"}>
        <span className="live-dot" />
        <span>
          {connected ? "В эфире" : "Нет связи"}
          {stats?.last_collect_at ? `, сбор в ${clock(stats.last_collect_at)}` : ""}
        </span>
      </span>
      <div className="top-stats">
        <span className="stat crit"><b>{crit}</b> CRITICAL</span>
        <span className="stat high"><b>{high}</b> HIGH</span>
        <span className="stat"><b>{stats?.drafts ?? 0}</b> черновиков</span>
        <span className="stat"><b>{stats?.scheduled ?? 0}</b> в очереди</span>
        <span className="stat"><b>{stats?.published_24h ?? 0}</b> за сутки</span>
      </div>
      <div className="top-actions">
        <button className="btn small" onClick={onCollect} disabled={collecting} aria-label="Собрать сейчас">
          {collecting ? <span className="spin" /> : <IconRefresh />}
          <span className="hide-m">Собрать сейчас</span>
        </button>
        <button className="btn small ghost" onClick={onSources} aria-label="Источники">
          <IconAntenna />
          <span className="hide-m">Источники</span>
          {stats?.sources_failing ? <b style={{ color: "var(--siren)" }}>{stats.sources_failing}</b> : null}
        </button>
        {!demo && (
          <button className="btn small ghost" onClick={onLogout}>
            Выйти
          </button>
        )}
      </div>
    </header>
  );
}

export function SourcesDrawer({ api, onClose }) {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState(null);
  useEffect(() => {
    api.sources().then(setRows).catch((e) => setError(e.message));
  }, [api]);
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return (
    <>
      <div className="overlay" style={{ background: "rgba(5,3,12,.5)" }} onClick={onClose} />
      <aside className="drawer" aria-label="Источники">
        <div className="drawer-head">
          <h2>Источники</h2>
          <button className="btn small ghost" onClick={onClose} aria-label="Закрыть">
            <IconX />
          </button>
        </div>
        <div className="drawer-body">
          {error && <p className="err">{error}</p>}
          {!rows && !error && <p style={{ color: "var(--ink-3)" }}>Загружаю…</p>}
          {rows?.map((s) => {
            const health = !s.enabled ? "off" : s.consecutive_failures ? "bad" : "";
            return (
              <div className="src" key={s.key}>
                <div className="src-name">
                  <span className={`src-health ${health}`} />
                  {SCENES[s.scene]?.flag} {s.name}
                  <small>{s.kind === "telegram" ? "Telegram" : s.kind === "rss" ? "RSS" : "сайт"}</small>
                </div>
                <small>
                  {!s.enabled
                    ? "выключен"
                    : s.last_success_at
                      ? `последний успешный сбор ${ago(s.last_success_at)}`
                      : "ещё не собирался"}
                  {s.items_total ? `, всего публикаций: ${s.items_total}` : ""}
                </small>
                {s.last_error && s.enabled && <span className="err">{s.last_error}</span>}
                {s.note && <small>{s.note}</small>}
              </div>
            );
          })}
        </div>
      </aside>
    </>
  );
}
