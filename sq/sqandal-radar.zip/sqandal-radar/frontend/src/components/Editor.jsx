import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ago,
  ageHours,
  safeHref,
  clock,
  CONFIDENCE,
  copyPost,
  DATE_SOURCE,
  FLAG_EMOJI,
  MODE,
  NEXT_MODE,
  SCENES,
  stamp,
  telegramLength,
  toLocalInput,
  TOPIC_EMOJI,
  VERIFICATION,
} from "../lib/format.js";
import {
  IconBack,
  IconCheck,
  IconClock,
  IconCopy,
  IconEye,
  IconFlame,
  IconPlus,
  IconSend,
  IconWarn,
  IconX,
} from "./Icons.jsx";

const EDITABLE = new Set(["draft", "scheduled", "failed"]);

function freshnessColor(ratio) {
  if (ratio < 0.25) return "var(--siren-blue)";
  if (ratio < 0.75) return "var(--sodium)";
  return "var(--siren)";
}

function Origin({ story, staleAfter, now }) {
  const o = story.origin;
  const age = ageHours(o.published_at, now);
  const ratio = Math.min(1, age / staleAfter);
  return (
    <section className={`origin ${story.is_stale ? "stale" : ""}`} aria-label="Первоисточник">
      <div className="origin-time">{clock(o.published_at)}</div>
      <div className="origin-what">
        Первоисточник: <b>{o.source_name ?? "—"}</b>, {stamp(o.published_at, now)}
      </div>
      <div className="origin-how">
        {ago(o.published_at, now)}, {DATE_SOURCE[o.date_source] ?? "дата"} ({CONFIDENCE[o.confidence]})
        {story.is_stale && <>. Старше {staleAfter} ч — перед отправкой будет вопрос</>}
      </div>
      <div className="fresh" title={`Возраст новости относительно порога ${staleAfter} ч`}>
        <i style={{ width: `${Math.max(4, ratio * 100)}%`, background: freshnessColor(ratio) }} />
      </div>
    </section>
  );
}

function Timeline({ items, now }) {
  return (
    <section>
      <h3 className="section-title">Источники по времени выхода</h3>
      <ol className="timeline">
        {items.map((it, i) => (
          <li key={it.id}>
            <div className="tl-time">
              {clock(it.effective_at)}
              <small>{stamp(it.effective_at, now).split(",")[0]}</small>
            </div>
            <div>
              <div className="tl-src">
                <b>{it.source_name}</b>
                <span>{it.source_kind === "telegram" ? "Telegram" : "СМИ"}</span>
                {i === 0 && <span className="first">первым</span>}
                <span>{DATE_SOURCE[it.date_source]}</span>
                {it.fwd_from && <span>репост: {it.fwd_from}</span>}
                {it.tg_views ? <span>{it.tg_views.toLocaleString("ru-RU")} просмотров</span> : null}
              </div>
              {safeHref(it.url) ? (
                <a className="tl-title" href={safeHref(it.url)} target="_blank" rel="noreferrer">
                  {it.title}
                </a>
              ) : (
                <span className="tl-title">{it.title}</span>
              )}
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}

function TelegramPreview({ post, cfg }) {
  const bullets = post.bullets.filter((b) => b.trim());
  const len = telegramLength(post, cfg);
  const summary = post.summary.trim();
  const style = cfg.summary_style;
  return (
    <section className="tg" aria-label="Предпросмотр поста в Telegram">
      <div className="tg-chan">
        <span className="tg-ava">🔊</span>
        <span>
          <b>SQANDAL</b>
          <small>{cfg.channel}</small>
        </span>
      </div>
      <div className="tg-bubble">
        {(post.flag_emoji || post.topic_emoji) && <>{post.flag_emoji}{post.topic_emoji} </>}
        <b>{post.headline.trim() || "Заголовок"}</b>
        {"\n\n"}
        {bullets.map((b, i) => (
          <span key={i}>
            {cfg.bullet} {b.trim()}
            {"\n"}
          </span>
        ))}
        {summary &&
          (style === "quote" ? (
            <>
              {"\n"}
              <span className="tg-quote">{summary}</span>
            </>
          ) : (
            <>
              {"\n"}
              {style === "bold" ? <b>{summary}</b> : style === "italic" ? <i>{summary}</i> : summary}
              {"\n"}
            </>
          ))}
        {post.footnotes?.length ? (
          <>
            {"\n"}
            {post.footnotes.map((f, i) => (
              <i key={i}>* {f}{"\n"}</i>
            ))}
          </>
        ) : null}
        {"\n"}
        {cfg.show_sources && post.sources?.length ? (
          <>
            📎{" "}
            {post.sources.slice(0, 4).map((s, i) => (
              <span key={s.name}>
                {i > 0 && " · "}
                {safeHref(s.url) ? (
                  <a href={safeHref(s.url)} target="_blank" rel="noreferrer">
                    {s.name}
                  </a>
                ) : (
                  s.name
                )}
              </span>
            ))}
            {"\n"}
          </>
        ) : null}
        {cfg.brand_url ? (
          <a href={cfg.brand_url} target="_blank" rel="noreferrer">
            {cfg.brand_line}
          </a>
        ) : (
          <b>{cfg.brand_line}</b>
        )}
        <div className="tg-foot">
          <span>
            <IconEye /> —
          </span>
          <span>{clock(new Date().toISOString())}</span>
        </div>
      </div>
      <div className={`tg-count ${len > 4096 ? "over" : ""}`}>
        {len} из 4096 символов{len > 4096 ? " — Telegram не примет, сократи" : ""}
      </div>
    </section>
  );
}

function PostFields({ draft, setDraft, readOnly }) {
  const setBullet = (i, v) => setDraft((d) => ({ ...d, bullets: d.bullets.map((b, j) => (j === i ? v : b)) }));
  return (
    <section className="fields" aria-label="Текст поста">
      <div className="field">
        <span className="lbl">Флаг и тема</span>
        <div className="emoji-row">
          {FLAG_EMOJI.map((f) => (
            <button key={f} type="button" className="emoji" aria-pressed={draft.flag_emoji === f}
              disabled={readOnly} onClick={() => setDraft((d) => ({ ...d, flag_emoji: f }))}>
              {f}
            </button>
          ))}
        </div>
        <div className="emoji-row">
          {TOPIC_EMOJI.map((t) => (
            <button key={t || "none"} type="button" className="emoji" aria-pressed={draft.topic_emoji === t}
              disabled={readOnly} onClick={() => setDraft((d) => ({ ...d, topic_emoji: t }))}
              aria-label={t ? `Тема ${t}` : "Без эмодзи темы"}>
              {t || <IconX />}
            </button>
          ))}
        </div>
      </div>
      <div className="field">
        <label htmlFor="pf-head">Заголовок</label>
        <input id="pf-head" className="input" value={draft.headline} readOnly={readOnly}
          onChange={(e) => setDraft((d) => ({ ...d, headline: e.target.value }))} />
      </div>
      <div className="field">
        <span className="lbl">Факты (3–4 пункта)</span>
        {draft.bullets.map((b, i) => (
          <div className="bullet-row" key={i}>
            <textarea className="textarea" rows={2} value={b} readOnly={readOnly} aria-label={`Пункт ${i + 1}`}
              onChange={(e) => setBullet(i, e.target.value)} />
            {!readOnly && (
              <button type="button" className="btn small ghost" aria-label={`Удалить пункт ${i + 1}`}
                onClick={() => setDraft((d) => ({ ...d, bullets: d.bullets.filter((_, j) => j !== i) }))}>
                <IconX />
              </button>
            )}
          </div>
        ))}
        {!readOnly && draft.bullets.length < 4 && (
          <button type="button" className="btn small ghost" style={{ justifySelf: "start" }}
            onClick={() => setDraft((d) => ({ ...d, bullets: [...d.bullets, ""] }))}>
            <IconPlus /> Добавить пункт
          </button>
        )}
      </div>
      <div className="field">
        <label htmlFor="pf-sum">Итог одной фразой</label>
        <textarea id="pf-sum" className="textarea" rows={2} value={draft.summary} readOnly={readOnly}
          onChange={(e) => setDraft((d) => ({ ...d, summary: e.target.value }))} />
      </div>
    </section>
  );
}

function StaleDialog({ reason, onConfirm, onCancel, busy }) {
  const ref = useRef(null);
  useEffect(() => {
    ref.current?.focus();
    const onKey = (e) => e.key === "Escape" && onCancel();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-labelledby="stale-title">
      <div className="dialog">
        <h2 id="stale-title">Это может быть старый факт</h2>
        <p>{reason}</p>
        <p>Проверь дату у первоисточника. Если новость актуальна — отправляй.</p>
        <div className="row-btns">
          <button className="btn ghost" onClick={onCancel} ref={ref}>Не отправлять</button>
          <button className="btn hot" onClick={onConfirm} disabled={busy}>
            {busy ? <span className="spin" /> : <IconSend />} Всё равно отправить
          </button>
        </div>
      </div>
    </div>
  );
}

const fieldsOf = (p) => ({
  flag_emoji: p.flag_emoji,
  topic_emoji: p.topic_emoji,
  headline: p.headline,
  bullets: [...p.bullets],
  summary: p.summary,
});

export function Editor({ api, cfg, storyId, cardVersion, open, onClose, toast, onChanged, now }) {
  const [detail, setDetail] = useState(null);
  const [error, setError] = useState(null);
  const [draft, setDraft] = useState(null);
  const [busy, setBusy] = useState(null);
  const [schedOpen, setSchedOpen] = useState(false);
  const [schedAt, setSchedAt] = useState("");
  const [stale, setStale] = useState(null);
  const post = detail?.current_post ?? null;
  const dirty = useMemo(
    () => post && draft && JSON.stringify(fieldsOf(post)) !== JSON.stringify(draft),
    [post, draft],
  );

  const load = useCallback(
    async (keepDraft = false) => {
      try {
        const d = await api.story(storyId);
        setDetail(d);
        setError(null);
        if (!keepDraft) setDraft(d.current_post ? fieldsOf(d.current_post) : null);
      } catch (e) {
        setError(e.message);
      }
    },
    [api, storyId],
  );

  useEffect(() => {
    if (!storyId) return;
    setDetail(null);
    setDraft(null);
    setSchedOpen(false);
    load();
  }, [storyId, load]);

  // сюжет обновился в эфире (новый источник, публикация с другого устройства)
  const lastVersion = useRef(cardVersion);
  useEffect(() => {
    if (!storyId || cardVersion === lastVersion.current) return;
    lastVersion.current = cardVersion;
    if (!dirty && !busy) load();
  }, [cardVersion, storyId, dirty, busy, load]);

  if (!storyId) {
    return (
      <section className={`editor ${open ? "open" : ""}`}>
        <div className="editor-empty">
          <h2>Выбери сюжет слева</h2>
          <p>Здесь будет готовый пост для канала, время первоисточника и все источники. CRITICAL-сюжеты в ленте
            отмечены сиреной.</p>
        </div>
      </section>
    );
  }
  if (error) {
    return (
      <section className={`editor ${open ? "open" : ""}`}>
        <div className="editor-empty">
          <h2>Сюжет не открылся</h2>
          <p>{error}</p>
          <button className="btn" onClick={() => load()}>Повторить</button>
        </div>
      </section>
    );
  }
  if (!detail) {
    return (
      <section className={`editor ${open ? "open" : ""}`}>
        <div className="editor-empty"><p>Загружаю сюжет…</p></div>
      </section>
    );
  }

  const readOnly = !post || !EDITABLE.has(post.status);
  const shown = draft && post ? { ...post, ...draft } : post;
  const nextMode = post ? NEXT_MODE[post.mode] : "standard";

  async function run(kind, fn) {
    setBusy(kind);
    try {
      return await fn();
    } catch (e) {
      if (e.code === "stale_confirmation_required") {
        setStale(e.message);
        return null;
      }
      toast({ kind: "err", text: e.message });
      return null;
    } finally {
      setBusy(null);
    }
  }

  async function saveIfDirty() {
    if (!dirty) return post;
    const p = await api.patchPost(post.id, draft);
    setDetail((d) => ({ ...d, current_post: p }));
    setDraft(fieldsOf(p));
    return p;
  }

  const generate = (mode) =>
    run(mode === "standard" ? "generate" : "harder", async () => {
      if (dirty) await saveIfDirty();
      await api.generate(detail.id, mode);
      await load();
      onChanged();
      toast({ kind: "ok", text: mode === "standard" ? "Пост готов" : `Новый вариант: ${MODE[mode]}` });
    });

  const publish = (confirm = false) =>
    run("publish", async () => {
      await saveIfDirty();
      const p = await api.publish(post.id, confirm);
      if (!p) return;
      setStale(null);
      await load();
      onChanged();
      toast({ kind: "ok", text: `Опубликовано в ${cfg.channel}`, link: p.link ? { href: p.link, label: "Открыть пост" } : null });
    });

  const save = () =>
    run("save", async () => {
      await saveIfDirty();
      onChanged();
      toast({ kind: "ok", text: "Правки сохранены" });
    });

  const schedule = () =>
    run("schedule", async () => {
      await saveIfDirty();
      await api.schedule(post.id, new Date(schedAt).toISOString());
      setSchedOpen(false);
      await load();
      onChanged();
      toast({ kind: "ok", text: `Запланировано на ${clock(new Date(schedAt).toISOString())}` });
    });

  const unschedule = () =>
    run("schedule", async () => {
      await api.unschedule(post.id);
      await load();
      onChanged();
      toast({ text: "Публикация снята с очереди" });
    });

  const copy = async () => {
    const ok = await copyPost(shown, cfg);
    toast(ok ? { kind: "ok", text: "Пост скопирован — вставь в Telegram" } : { kind: "err", text: "Не удалось скопировать: выдели текст в предпросмотре вручную" });
  };

  const dismiss = () =>
    run("dismiss", async () => {
      await (detail.status === "dismissed" ? api.restore(detail.id) : api.dismiss(detail.id));
      await load(true);
      onChanged();
    });

  const openSchedule = () => {
    const d = new Date(Date.now() + 60 * 60 * 1000);
    d.setMinutes(Math.ceil(d.getMinutes() / 5) * 5, 0, 0);
    setSchedAt(toLocalInput(d));
    setSchedOpen(true);
  };

  return (
    <section className={`editor ${open ? "open" : ""}`} aria-label="Редактор поста">
      <div className="editor-inner">
        <button className="btn small ghost ed-back" onClick={onClose}>
          <IconBack /> Лента
        </button>

        <header className="ed-head">
          <div className="ed-sub">
            {post?.status !== "published" && (
              <button className="btn small ghost ed-hide" onClick={dismiss} disabled={!!busy}>
                {detail.status === "dismissed" ? "Вернуть в ленту" : "Скрыть сюжет"}
              </button>
            )}
            <span className={`prio ${detail.priority}`}>{detail.priority}</span>
            <span>{SCENES[detail.scene]?.flag} {SCENES[detail.scene]?.label}</span>
            {detail.tags.map((t) => (
              <span key={t} className={`tag t-${t}`}>#{t}</span>
            ))}
            <span className={`badge ${detail.verification === "insider_only" ? "insider" : ""}`}>
              {VERIFICATION[detail.verification]}
            </span>
          </div>
          <h1 className="ed-title">{detail.title}</h1>
        </header>

        <Origin story={detail} staleAfter={cfg.stale_after_hours} now={now} />

        {(post?.warnings?.length > 0 || detail.republish_of || detail.needs_refresh) && (
          <ul className="warnings">
            {detail.needs_refresh && (
              <li><IconWarn /> После черновика пришли новые источники — перегенерируй, чтобы учесть их.</li>
            )}
            {post?.warnings?.map((w) => (
              <li key={w}><IconWarn /> {w}</li>
            ))}
          </ul>
        )}

        {!post ? (
          <section className="fields">
            <p style={{ color: "var(--ink-2)", margin: 0 }}>
              Поста ещё нет — авто-генерация пропускает старые и низкоприоритетные сюжеты. Сгенерируй вручную, это
              несколько секунд.
            </p>
            <button className="btn primary" style={{ justifySelf: "start" }} onClick={() => generate("standard")}
              disabled={!!busy || !cfg.llm_ready}>
              {busy === "generate" ? <span className="spin" /> : <IconFlame />}
              Сгенерировать пост
            </button>
            {!cfg.llm_ready && <p className="notes">LLM не настроен — задай ANTHROPIC_API_KEY.</p>}
          </section>
        ) : (
          <>
            <div className="post-grid">
              <TelegramPreview post={shown} cfg={cfg} />
              <PostFields draft={draft ?? fieldsOf(post)} setDraft={setDraft} readOnly={readOnly} />
            </div>
            {post.editor_notes && <p className="notes">Заметка модели: {post.editor_notes}</p>}
            <p className="ed-sub">
              Версия {post.version}: {MODE[post.mode]}
              {post.llm_model ? `, ${post.llm_model}` : ""}
              {post.cache_read_tokens ? `, из кэша ${post.cache_read_tokens} токенов` : ""}
            </p>
          </>
        )}

        <Timeline items={detail.items} now={now} />

        <div className={`actions ${post ? "" : "empty"}`}>
            {!post ? null : post.status === "published" ? (
              <span className="done">
                <IconCheck /> Опубликовано {post.published_at ? stamp(post.published_at, now) : ""}
                {post.link && (
                  <a href={post.link} target="_blank" rel="noreferrer" style={{ color: "var(--tg-link)" }}>
                    открыть
                  </a>
                )}
              </span>
            ) : schedOpen ? (
              <div className="sched">
                <label className="sr-only" htmlFor="sched-at">Время публикации</label>
                <input id="sched-at" type="datetime-local" value={schedAt} onChange={(e) => setSchedAt(e.target.value)} />
                <button className="btn primary" onClick={schedule} disabled={!schedAt || !!busy}>
                  {busy === "schedule" ? <span className="spin" /> : <IconClock />}
                  Запланировать на {schedAt ? schedAt.slice(11, 16) : "…"}
                </button>
                <button className="btn ghost" onClick={() => setSchedOpen(false)}>Отмена</button>
              </div>
            ) : (
              <>
                <button className="btn primary" onClick={() => publish(false)} disabled={!!busy || readOnly || !cfg.bot_ready}
                  title={cfg.bot_ready ? "" : "Bot API не настроен: TG_BOT_TOKEN"}>
                  {busy === "publish" ? <span className="spin" /> : <IconSend />}
                  <span>Отправить<span className="hide-m"> в канал</span></span>
                </button>
                {post.status === "scheduled" ? (
                  <button className="btn" onClick={unschedule} disabled={!!busy}>
                    <IconClock /> В {clock(post.scheduled_at)} — снять
                  </button>
                ) : (
                  <button className="btn" onClick={openSchedule} disabled={!!busy || readOnly}>
                    <IconClock /> Запланировать
                  </button>
                )}
                <button className="btn hot" onClick={() => generate(nextMode)} disabled={!!busy || readOnly || !cfg.llm_ready}>
                  {busy === "harder" ? <span className="spin" /> : <IconFlame />}
                  {post.mode === "harder" ? "Ещё жёстче" : post.mode === "hardest" ? "Ещё вариант" : (
                    <span><span className="hide-m">Перегенерировать жёстче</span><span className="show-m">Жёстче</span></span>
                  )}
                </button>
                <button className="btn ghost" onClick={copy}>
                  <IconCopy /> Скопировать
                </button>
                {dirty && (
                  <button className="btn ghost" onClick={save} disabled={!!busy}>
                    {busy === "save" ? <span className="spin" /> : null}
                    Сохранить правки
                  </button>
                )}
              </>
            )}
        </div>
      </div>
      {stale && (
        <StaleDialog reason={stale} busy={busy === "publish"} onCancel={() => setStale(null)} onConfirm={() => publish(true)} />
      )}
    </section>
  );
}
