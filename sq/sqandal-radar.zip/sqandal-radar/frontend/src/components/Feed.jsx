import { compactAgo, clock, plural, SCENES, STATUS, VERIFICATION } from "../lib/format.js";

const TABS = [
  { key: "ru", flag: "🇷🇺", label: "СНГ" },
  { key: "de", flag: "🇩🇪", label: "GER" },
  { key: "us", flag: "🇺🇸", label: "US" },
  { key: "all", flag: null, label: "ALL" },
];

export function SceneTabs({ scene, onScene, counts, critical }) {
  const total = Object.values(counts ?? {}).reduce((a, b) => a + b, 0);
  return (
    <div className="scenes" role="tablist" aria-label="Сцена">
      {TABS.map((t) => {
        const n = t.key === "all" ? total : counts?.[t.key] ?? 0;
        return (
          <button
            key={t.key}
            role="tab"
            aria-selected={scene === t.key}
            className="scene"
            onClick={() => onScene(t.key)}
          >
            {t.flag && <span className="scene-flag">{t.flag}</span>}
            <span className="scene-name">{t.label}</span>
            <span className="scene-count">{n}</span>
            {critical.has(t.key) && <span className="crit-dot" title="Есть CRITICAL" />}
          </button>
        );
      })}
    </div>
  );
}

export function Filters({ filters, setFilters, tags }) {
  const toggle = (key, value) =>
    setFilters((f) => {
      const set = new Set(f[key]);
      set.has(value) ? set.delete(value) : set.add(value);
      return { ...f, [key]: [...set] };
    });
  return (
    <div className="filters">
      {["CRITICAL", "HIGH", "NORMAL"].map((p) => (
        <button
          key={p}
          className={`chip p-${p}`}
          aria-pressed={filters.priorities.includes(p)}
          onClick={() => toggle("priorities", p)}
        >
          {p}
        </button>
      ))}
      {tags.map((t) => (
        <button
          key={t.name}
          className="chip"
          aria-pressed={filters.tag === t.name}
          onClick={() => setFilters((f) => ({ ...f, tag: f.tag === t.name ? "" : t.name }))}
        >
          #{t.name}
        </button>
      ))}
      <span className="grow" />
      <input
        className="search"
        type="search"
        placeholder="Поиск по артисту или заголовку"
        value={filters.q}
        onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))}
        aria-label="Поиск"
      />
      <select
        className="select"
        value={filters.status}
        onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
        aria-label="Статус"
      >
        <option value="active">В работе</option>
        <option value="published">Опубликованные</option>
        <option value="dismissed">Скрытые</option>
        <option value="all">Все</option>
      </select>
      <select
        className="select"
        value={filters.sort}
        onChange={(e) => setFilters((f) => ({ ...f, sort: e.target.value }))}
        aria-label="Сортировка"
      >
        <option value="time">Сначала свежие</option>
        <option value="priority">Сначала важные</option>
      </select>
    </div>
  );
}

export function StoryRow({ s, selected, flash, onOpen, now }) {
  const staleish = s.is_stale || s.republish_of;
  const others = s.sources_count - 1;
  return (
    <button
      className={`row p-${s.priority} ${flash ? "flash" : ""} ${s.status === "dismissed" ? "dim" : ""}`}
      aria-current={selected}
      onClick={() => onOpen(s.id)}
    >
      <div className="row-top">
        <span className={`prio ${s.priority}`}>{s.priority}</span>
        <span>{SCENES[s.scene]?.flag}</span>
        <span>{s.origin.source_name}{others > 0 ? ` и ещё ${others}` : ""}</span>
        <span className="row-time" title="Время первоисточника">
          <b>{clock(s.origin.published_at)}</b>&nbsp; {compactAgo(s.origin.published_at, now)}
        </span>
      </div>
      <div className="row-title">{s.title}</div>
      <div className="row-meta">
        {s.tags.map((t) => (
          <span key={t} className={`tag t-${t}`}>#{t}</span>
        ))}
        {s.verification === "insider_only" && <span className="badge insider">{VERIFICATION.insider_only}</span>}
        {s.verification === "multi_source" && (
          <span className="badge">{s.sources_count} {plural(s.sources_count, "источник", "источника", "источников")}</span>
        )}
        {staleish && <span className="badge stale">{s.is_stale ? "старый факт" : "повтор"}</span>}
        {s.post?.status === "scheduled" ? (
          <span className="badge st-scheduled">в {clock(s.post.scheduled_at)}</span>
        ) : s.status !== "new" ? (
          <span className={`badge st-${s.status}`}>{STATUS[s.status]}</span>
        ) : null}
        {s.needs_refresh && <span className="badge insider">новые источники</span>}
      </div>
    </button>
  );
}

export function Feed({ stories, loading, error, selectedId, flashIds, onOpen, onCollect, now }) {
  if (error) {
    return (
      <section className="feed">
        <div className="feed-empty">
          <h3>Ленту не загрузить</h3>
          <p>{error}</p>
        </div>
      </section>
    );
  }
  if (!loading && stories.length === 0) {
    return (
      <section className="feed">
        <div className="feed-empty">
          <h3>Тихо</h3>
          <p>По этим фильтрам сюжетов нет. Сбор идёт каждые 15 минут, Telegram-каналы — сразу.</p>
          <button className="btn small" onClick={onCollect}>Собрать сейчас</button>
        </div>
      </section>
    );
  }
  return (
    <section className="feed" aria-label="Лента сюжетов" aria-busy={loading}>
      {stories.map((s) => (
        <StoryRow key={s.id} s={s} selected={s.id === selectedId} flash={flashIds.has(s.id)} onOpen={onOpen} now={now} />
      ))}
    </section>
  );
}
