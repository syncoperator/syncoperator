import { StrictMode, useCallback, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { Login } from "./components/Login.jsx";
import { createApi } from "./lib/api.js";
import "./styles.css";

const KEY = "sqandal.token";
const wantsDemo = __DEMO__ || new URLSearchParams(location.search).has("demo");

function readToken() {
  try {
    return localStorage.getItem(KEY) || "";
  } catch {
    return "";
  }
}

function Root() {
  const [api, setApi] = useState(null);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (wantsDemo) {
      // демо-данные грузятся отдельным чанком только по требованию
      import("./demo/demoApi.js").then((m) => setApi(m.createDemoApi()));
      return;
    }
    const t = readToken();
    if (t) setApi(createApi(t));
  }, []);

  const login = useCallback(async (token) => {
    setBusy(true);
    setError(null);
    const candidate = createApi(token);
    try {
      await candidate.config();
      try {
        localStorage.setItem(KEY, token);
      } catch {
        /* приватный режим — живём без запоминания */
      }
      setApi(candidate);
    } catch (e) {
      setError(e.status === 401 ? "Токен не подошёл — проверь DASHBOARD_TOKEN в .env" : e.message);
    } finally {
      setBusy(false);
    }
  }, []);

  const logout = useCallback(() => {
    try {
      localStorage.removeItem(KEY);
    } catch {
      /* ignore */
    }
    setApi(null);
  }, []);

  if (!api) return wantsDemo ? null : <Login onLogin={login} error={error} busy={busy} />;
  return <App api={api} onLogout={logout} />;
}

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <Root />
  </StrictMode>,
);
